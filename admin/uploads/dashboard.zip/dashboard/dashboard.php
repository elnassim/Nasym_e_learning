<?php

include '../../source/mysqlcon.php';
session_start();
// Retrieve administrator information
$query = "SELECT FirstName, LastName, ProfilePicture FROM Admins ";
$result = $conn->query($query);

if ($result && $result->rowCount() > 0) {
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $firstName = $row['FirstName'];
    $lastName = $row['LastName'];
    $profileImage = $row['ProfilePicture'];
} else {
    // Handle case where no administrator is found
    $firstName = 'Name';
    $lastName = 'Unknown';
    $profileImage = 'default.jpg'; // Remplacez "default.jpg" par le nom de votre image de profil par défaut
}

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NASYM</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../test/styles/dashboard.css">
</head>
<body>
  
  
  <div class="container">
        <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo"><img class="logo-image" src="../style//LGG-removebg-preview.png" alt="logo"></div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">Home</a></li>
            
            <li><a href="user_management.php">Manage Teachers</a></li>
            <li><a href="course_management.php">Manage Courses</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <li><a href="enrollment_management.php">Manage Enrollments</a></li>
            <li><a href="support_maintenance.php">Support and Maintenance</a></li>
            <li><a href="contact.php">Contact</a></li>
           

        </ul>
        
        <div class="sidebar-profile">
            <div class="profile-header">
                <h3><?php echo $firstName . ' ' . $lastName; ?></h3>
            </div>
            <div class="profile-photo">
                <img id="profile-image" src="images/<?php echo $profileImage; ?>" alt="Profile Image">
            </div>
            <div class="profile-menu">
                <form action="update_profile.php" method="POST" enctype="multipart/form-data">
                    <label for="profile-image-upload">Change Profile Picture</label>
                    <input type="file" id="profile-image-upload" name="profile-image-upload">
                    <button type="submit">Save</button>
                    <hr>
                    <ul class="sidebar-menu">
                        <li><a href="about.php"><i class='bx bx-log-out'></i>log out</a></li>
                    </ul>
                </form>
            </div>
        </div>
    </div>


<div class="content">
       
 <!-- Add your Course Overview, Course Progress, and Attendance sections here -->
 <div class="dashboard-sections">
    <div class="dashboard-section" >
       <button><a href="user_management.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
    
          <span class="text"  >Manage Teachers</span>
        </div>
    </div>
    <div class="dashboard-section" >
       <button><a href="course_management.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
    
          <span class="text"  >Manage Courses</span>
        </div>
    </div>
    </div>

    <div class="dashboard-sections">
    <div class="dashboard-section">
       <button><a href="statistics.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
          <span class="text">Statistics</span>
        </div>
    </div>
    <div class="dashboard-section">
       <button><a href="enrollment_management.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
          <span class="text">Manage Enrollments</span>
        </div>
    </div>
</div>

    <div class="dashboard-sections">
    <div class="dashboard-section" >
       <button><a href="support_maintenance.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
    
          <span class="text"  >Support and Maintenance</span>
        </div>
    </div>
    <div class="dashboard-section" >
       <button><a href="contact.php">
       <img src="../style/1std.png" alt="Description de l'image">
        </a></button>
  
        <div class="bar" align="center">
    
          <span class="text"  >Contact</span>
        </div>
    </div>
    </div>

</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</body>
</html>